A C++11 port of [kdbush](https://github.com/mourner/kdbush), a fast static spatial index for 2D points.

[![Build Status](https://travis-ci.org/mourner/kdbush.hpp.svg?branch=master)](https://travis-ci.org/mourner/kdbush.hpp)
