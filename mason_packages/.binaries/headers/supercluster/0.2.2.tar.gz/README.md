A C++14 port of [supercluster](https://github.com/mapbox/supercluster), a fast 2D point clustering library for use in interactive maps.

[![Build Status](https://travis-ci.org/mapbox/supercluster.hpp.svg?branch=master)](https://travis-ci.org/mapbox/supercluster.hpp)
